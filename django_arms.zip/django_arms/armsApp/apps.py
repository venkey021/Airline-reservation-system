import imp
from django.apps import AppConfig


class armsAppConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'armsApp'
